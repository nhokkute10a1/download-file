/*--Call-Server--*/
//var socket = io("https://chungthanhphuocapp.herokuapp.com");
let urlLocal = 'http://localhost:3000';
//let urlServer = 'https://zplus-app.herokuapp.com';
//let urlServer = 'http://realtime-server.azurewebsites.net'
let socket = io(urlLocal, {
    jsonp: false,
    reconnection: true,
    transports: ['websocket']
});
jQuery(() => {
    let self = RealtimeTracking;
    self.InitRealtime();
    jQuery("#btnClearLogTracking").click(() => {
        self.ClearLog();
    });
    jQuery("#btnClearLogTrackingInfo").click(() => {
        self.ClearLogInfo();
    });
    jQuery("#btnSendData").click(() => {
        self.SendData();
    });
});
let RealtimeTracking = {
    InitRealtime: () => {
        /*--Validate--*/
        socket.on('connect', () => {
            jQuery('#displayStatus').text('Connected to server');
        });
        socket.on('disconnect', () => {
            jQuery('#displayStatus').text('Máy chủ realtime hiện tại không hoạt động');
        });
        socket.on('reconnect', () => {
            jQuery('#displayStatus').text('Kết nối lại với máy chủ realtime thành công');
        });
        socket.on('connect_failed', () => {
            jQuery('#displayStatus').text('Có lỗi xảy ra trong quá trình kết nối máy chủ');
        });
        /*--Listen-Client--*/
        socket.on('tracking-client-connect', (data) => {
            html = '';
            html += "<li class='list-group-item'>" + data + "</li>";
            jQuery('#tracking').append(html);
        });
        socket.on('tracking-client-disconnected', (data) => {
            html = "";
            html += "<li class='list-group-item'>" + data + "</li>";
            jQuery('#tracking').append(html);
        });
        socket.on('client-send-data', (data) => {
            html = "";
            html += "<li class='list-group-item'>" + data + "</li>";
            jQuery('#trackingInfo').append(html);
        });
        socket.on('server-send-data-test', (data) => {
            html = "";
            html += "<li class='list-group-item'>" + data + "</li>";
            jQuery('#trackingInfo').append(html);
        });
    },
    ClearLog: () => {
        jQuery('#tracking').html('');
    },
    ClearLogInfo: () => {
        jQuery('#trackingInfo').html('');
    },
    SendData: () => {
        socket.emit('client-send-data-test', new Date());
    }
};