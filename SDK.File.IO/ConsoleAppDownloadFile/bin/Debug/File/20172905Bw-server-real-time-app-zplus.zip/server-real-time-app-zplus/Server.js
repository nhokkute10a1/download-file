var express = require('express');
var app = express();
app.use(express.static('./public'));
var server = require('http').Server(app);
var io = require('socket.io')(server);
/*--Define-port-listen--*/
server.listen(process.env.PORT || 3000);
//server.listen(3000);
/*--Define-socket-io--*/
io.on('connection', (socket) => {
    /*==Server-Connect==*/
    console.log('Client connected to server ' + socket.id);
    /*==Server-Tracking==*/
    // io.emit('tracking-client-connect', () => {
    //     return 'Client connected to server ' + socket.id;
    // });
    socket.broadcast.emit('tracking-client-connect', 'Client connected to server ' + socket.id);
    /*==Listien from client==*/
    socket.on('client-send-data', (data) => {
        console.log('Server received ' + data);
        io.sockets.emit('server-send-data', data);
    });
    socket.on('client-send-data-test', (data) => {
        console.log('Server received ' + data);
        io.sockets.emit('server-send-data-test', data);
    });
    /*--Check-Disconnected--*/
    socket.on("disconnect", () => {
        console.log("Client " + socket.id + " disconnected");
        socket.broadcast.emit('tracking-client-disconnected', 'Client disconnected to server ' + socket.id);
    });
});
/*--Define-Route--*/
app.set("view engine", "ejs");
app.set("views", "./views");
app.get("/", function (req, res) {
    res.render("index");
});